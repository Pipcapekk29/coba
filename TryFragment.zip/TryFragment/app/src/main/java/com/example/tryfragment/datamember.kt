package com.example.tryfragment

data class datamember(
    var nama : Int,


)

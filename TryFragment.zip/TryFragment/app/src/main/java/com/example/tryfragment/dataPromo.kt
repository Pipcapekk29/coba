package com.example.tryfragment

data class dataPromo(
    var id : Int,
    var imagepromo : String,
    var title : String,
    var nama : String,
    var harga : Int

)

package com.example.tryfragment

data class DataHome(
    var id : Int,
    var imageHomeAdap : String,
)

package com.example.tryfragment

data class datagrid(
    var id : Int,
    var imageG : String,
    var title : String,
    var harga : Int,
    var hargamem : Int,
    var jumlah11 : Int,
)
